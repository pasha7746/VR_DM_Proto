﻿using UnityEngine;
using UnityEngine.UI;
using System.Data;
using System;
using Mono.Data.SqliteClient;
using System.Collections.Generic;
//using Mono.Data.Sqlite;
using System.IO;

public class MainViewRelative : MonoBehaviour
{
    public GameObject relimg;

    public Dropdown m_dropdown;

    public RawImage relmimg;

    public IDbConnection dbconn;
    public IDbCommand dbcmd;
    public IDataReader reader;

    public Text dtxt;
    public Text rtxt;

    [HideInInspector]
    public int relativechosen;

    [HideInInspector]
    public int pid;
    [HideInInspector]
    public string conn;

    [HideInInspector]
    public string path = "";

    public void OnMyValueChange(Dropdown dd)
    {
        string[] splitArray;
        int vl = dd.value;
        string vs = "";
        int rid = 0;

        relativechosen = vl;
        vs = dd.options[vl].text;
        splitArray = vs.Split('.');

        rid = Convert.ToInt32(splitArray[0]);

        WorkRID(rid);
        VacuumDB();

        rtxt.text = vs;

        LoadRelImage(rid);

    }
    void OnDestroy()
    {
        m_dropdown.onValueChanged.RemoveAllListeners();

    }
    void Start()
    {
        string pd = "";
        if (Application.platform != RuntimePlatform.Android)
        {
            path = Application.dataPath + "/StreamingAssets/PeopleDB.db";
        }
        else
        {
            path = Application.persistentDataPath + "/PeopleDB.db";
        }
        OpenDB("PeopleDB.db");
        pid = GetPID();
        pd = PopulateDetails();
        dtxt.text = pd;

        m_dropdown.onValueChanged.AddListener(delegate {
            OnMyValueChange(m_dropdown);
        });
    }
    public string PopulateDetails()
    {
        string conn = "";
        string tmpdr = "";
        string tmpres = "";
        string res = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT RID,name,relation FROM relatives where PID = " + pid;
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();
        List<string> list = new List<string>();
        list.Add("0. select");

        while (reader.Read())
        {
            tmpdr = tmpdr + reader.GetInt32(0) + ". " + reader.GetString(1) + ",\t\t\t" + reader.GetString(2) + "\n";
            tmpres = reader.GetInt32(0) + ". " + reader.GetString(1) + ", " + reader.GetString(2);
            list.Add(tmpres);
        }
        res = tmpdr;
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        m_dropdown.ClearOptions(); // better approach
        m_dropdown.AddOptions(list); // this is your required solution

        return res;
    }
    void LoadRelImage(int rid)
    {
        string conn = "";

        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string query = "SELECT Photo FROM relatives WHERE PID = " + pid + " and RID = " + rid + ";";

        dbcmd.CommandText = query;
        //reader = dbcmd.ExecuteReader();
        byte[] data = (byte[])dbcmd.ExecuteScalar();

        if (data != null)
        {
            //File.WriteAllBytes("woman2.jpg", data);
            Texture2D sampleTexture = new Texture2D(2, 2);
            bool isLoaded = sampleTexture.LoadImage(data);
            if (isLoaded)
            {
                relimg.GetComponent<RawImage>().texture = sampleTexture;
                relmimg.texture = sampleTexture;
            }
        }
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public int GetPID()
    {
        string conn = "";
        int res = 0;
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT PID FROM working";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();

        res = reader.GetInt32(0);

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    public void OpenDB(string p)
    {
        if (!File.Exists(path))
        {
            WWW loadDB = new WWW("jar:file://" + Application.dataPath + "!/assets/" + p);
            while (!loadDB.isDone) { }
            // then save to Application.persistentDataPath
            File.WriteAllBytes(path, loadDB.bytes);
        }
    }
    public void WorkRID(int rid)
    {
        string conn = "";

        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "update working set RID = " + rid;
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void VacuumDB()
    {
        string conn = "";
        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "PRAGMA auto_vacuum = FULL";
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
}
