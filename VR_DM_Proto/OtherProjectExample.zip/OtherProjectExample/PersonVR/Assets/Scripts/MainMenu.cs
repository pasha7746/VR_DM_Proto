﻿using UnityEngine;
using UnityEngine.UI;
using System.Data;
using System;
using Mono.Data.SqliteClient;
using System.Collections.Generic;
using System.IO;

public class MainMenu : MonoBehaviour
{
    public Dropdown m_dropdown;

    public GameObject img;

    public RawImage rmimg;

    public IDbConnection dbconn;
    public IDbCommand dbcmd;
    public IDataReader reader;

    public Text txt;
    public Text dtxt;

    [HideInInspector]
    public int relativechosen;
    [HideInInspector]
    public string conn;

    [HideInInspector]
    public string path = "";

    public void OnMyValueChange(Dropdown dd)
    {
        string[] splitArray;
        int vl = dd.value;
        string vs = "";
        int tid = 0;

        relativechosen = vl;
        vs = dd.options[vl].text;
        splitArray = vs.Split('.');

        tid = Convert.ToInt32(splitArray[0]);

        //EmptyTable();
        WorkPID(tid);
        VacuumDB();

        txt.text = vs;

        LoadImage(tid);
    }
    void OnDestroy()
    {
        m_dropdown.onValueChanged.RemoveAllListeners();

    }
    void Start ()
    {
        if (Application.platform != RuntimePlatform.Android)
        {
            path = Application.dataPath + "/StreamingAssets/PeopleDB.db";
        }
        else
        {
            path = Application.persistentDataPath + "/PeopleDB.db";
        }
        OpenDB("PeopleDB.db");
        dtxt.text = CreatePeopleList();
        m_dropdown.onValueChanged.AddListener(delegate {
            OnMyValueChange(m_dropdown);
        });

    }
    public string CreatePeopleList()
    {
        string conn = "";
        string tmpres = "";
        string tmprd = "";
        string res = "";

        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        List<string> list = new List<string>();
        list.Add("0. select a person");
        string sqlQuery = "SELECT PID,FirstName,LastName FROM persons order by FirstName,LastName";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();
        while (reader.Read())
        {
            tmpres = tmpres + reader.GetInt32(0) + ".\t\t" + reader.GetString(2) + ",\t\t\t" + reader.GetString(1) + "\n";
            tmprd = reader.GetInt32(0) + ". " + reader.GetString(2) + ", " + reader.GetString(1);
            list.Add(tmprd);
        }
        res = tmpres;

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        m_dropdown.ClearOptions(); // better approach
        m_dropdown.AddOptions(list); // this is your required solution

        return res;
    }
    void LoadImage(int tid)
    {
        string conn = "";

        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string query = "SELECT Photo FROM persons WHERE PID=" + tid + ";";

        dbcmd.CommandText = query;
        //reader = dbcmd.ExecuteReader();
        byte[] data = (byte[])dbcmd.ExecuteScalar();

        if (data != null)
        {
            //File.WriteAllBytes("woman2.jpg", data);
            Texture2D sampleTexture = new Texture2D(2, 2);
            bool isLoaded = sampleTexture.LoadImage(data);
            if (isLoaded)
            {
                img.GetComponent<RawImage>().texture = sampleTexture;
                rmimg.texture = sampleTexture;
            }
        }
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void OpenDB(string p)
    {
        if (!File.Exists(path))
        {
            WWW loadDB = new WWW("jar:file://" + Application.dataPath + "!/assets/" + p);
            while (!loadDB.isDone) { }
            // then save to Application.persistentDataPath
            File.WriteAllBytes(path, loadDB.bytes);
        }
    }
    public void WorkPID(int tid)
    {
        string conn = "";

        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "update working set RID = 0, PID = " + tid;
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void VacuumDB()
    {
        string conn = "";
        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "PRAGMA auto_vacuum = FULL";
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
}
