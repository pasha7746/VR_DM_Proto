﻿using UnityEngine;
using UnityEngine.UI;
using System.Data;
using System;
using Mono.Data.SqliteClient;
using System.Collections.Generic;
//using Mono.Data.Sqlite;
using System.IO;

public class MainEditRelative : MonoBehaviour
{
    public GameObject relimg;

    public InputField nl;

    public Dropdown m_dropdown;
    public Dropdown r_dropdown;

    public RawImage relmimg;

    public IDbConnection dbconn;
    public IDbCommand dbcmd;
    public IDataReader reader;

    public Text txt;
    public Text dtxt;
    public Text rtxt;

    [HideInInspector]
    public int pid;
    [HideInInspector]
    public int rid;
    [HideInInspector]
    public int relativechosen;
    [HideInInspector]
    public int relationchosen;

    [HideInInspector]
    public string conn;

    [HideInInspector]
    public string path = "";

    public void OnRValueChange(Dropdown dd)
    {
        int vl = dd.value;
        string vs = "";

        relationchosen = vl;
        vs = dd.options[vl].text;

        rtxt.text = vs;
    }
    public void OnMyValueChange(Dropdown dd)
    {
        string[] splitArray;
        string[] splitArray1;
        int vl = dd.value;
        string vs = "";
        string vs1 = "";
        string vs2 = "";
        int rl = 0;

        relativechosen = vl;
        vs = dd.options[vl].text;
        if (relativechosen == 0)
        {
            rid = 0;

            WorkRID();
            VacuumDB();

            nl.text = "";
            LoadEmptyImage();
        }
        else
        {
            splitArray = vs.Split('.');

            rid = Convert.ToInt32(splitArray[0]);

            WorkRID();
            VacuumDB();
            vs1 = splitArray[1];
            splitArray1 = vs1.Split(',');
            nl.text = splitArray1[0];
            vs2 = splitArray1[1].Trim();
            rl = GetLID(vs2);
            r_dropdown.value = rl;
            LoadRelImage();
        }
    }
    void OnDestroy()
    {
        m_dropdown.onValueChanged.RemoveAllListeners();
        r_dropdown.onValueChanged.RemoveAllListeners();

    }
    void Start ()
    {
        string pd = "";

        if (Application.platform != RuntimePlatform.Android)
        {
            path = Application.dataPath + "/StreamingAssets/PeopleDB.db";
        }
        else
        {
            path = Application.persistentDataPath + "/PeopleDB.db";
        }
        OpenDB("PeopleDB.db");
        pid = GetPID();
        pd = PopulateDropBox();
        txt.text = pd;
        PopulateRelationDropBox();
        m_dropdown.onValueChanged.AddListener(delegate {
            OnMyValueChange(m_dropdown);
        });
        r_dropdown.onValueChanged.AddListener(delegate {
                OnRValueChange(r_dropdown);
            });

    }
    public void PopulateRelationDropBox()
    {
        string tmpres = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT LID,relation FROM relations";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();
        List<string> list = new List<string>();
        list.Add("0. select");

        while (reader.Read())
        {
            tmpres = reader.GetString(1);
            list.Add(tmpres);
        }

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        r_dropdown.ClearOptions(); // better approach
        r_dropdown.AddOptions(list); // this is your required solution
    }
    public string PopulateDropBox()
    {
        string conn = "";
        string tmpdr = "";
        string tmpres = "";
        string res = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT RID,name,relation FROM relatives where PID = " + pid;
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();
        List<string> list = new List<string>();
        list.Add("0. Add Relative");

        while (reader.Read())
        {
            tmpres = tmpres + reader.GetInt32(0) + ". " + reader.GetString(1) + ",\t\t\t" + reader.GetString(2) + "\n";
            tmpdr = reader.GetInt32(0) + ". " + reader.GetString(1) + ", " + reader.GetString(2);
            list.Add(tmpdr);
        }
        res = tmpres;
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        m_dropdown.ClearOptions(); // better approach
        m_dropdown.AddOptions(list); // this is your required solution

        return res;
    }
    public void ButtonUpdateOnClick()
    {
        string ln = "";
        string fn = "";
        string pth = "";
        string pd = "";
        int drid = 0; ;

        ln = nl.text;
        pth = dtxt.text;
        fn = rtxt.text;
        
        if (rid == 0)
        {
            drid = GetRID() + 1;
            if (pth == "")
            {
                PersonDataAdd(drid,ln, fn);
            }
            else
            {
                PersonPhotoDataAdd(drid,ln, fn, pth);
            }
            pd = PopulateDropBox();
            txt.text = pd;
        }
        else
        {
            if (pth == "")
            {
                PersonDataUpdate(ln, fn);
            }
            else
            {
                PersonPhotoDataUpdate(ln, fn, pth);
            }

        }
        VacuumDB();
    }
    public void PersonDataAdd(int drid,string ln1, string fn1)
    {
        string conn = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "INSERT INTO relatives (PID,RID,relation,Name) VALUES (" + pid + "," + drid + ",'" + fn1 + "','" + ln1 + "')";

        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();

        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void PersonPhotoDataAdd(int drid,string ln1, string fn1, string pth)
    {
        string conn = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        byte[] data = null;

        data = File.ReadAllBytes(pth);

        IDbCommand dbcmd = dbconn.CreateCommand();

 //       dbcmd.CommandText = "UPDATE persons SET Photo = @img where PID = " + tid;
        dbcmd.CommandText = "INSERT INTO relatives (Photo,PID,RID,relation,name) VALUES (@img," + pid + "," + drid + ",'" + fn1 + "','" + ln1 + "');";
        dbcmd.Prepare();

        SqliteParameter param = new SqliteParameter("@img", DbType.Binary, data.Length);
        param.Value = data;
        dbcmd.Parameters.Add(param);

        dbcmd.ExecuteNonQuery();

        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void PersonDataUpdate(string ln1, string fn1)
    {
        string conn = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "Update relatives set relation = '" + fn1 + "', Name = '" + ln1 + "' where (PID = " + pid + " and RID = " + rid + ")";

        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();

        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void PersonPhotoDataUpdate(string ln1, string fn1, string pth)
    {
        string conn = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        byte[] data = null;

        data = File.ReadAllBytes(pth);

        IDbCommand dbcmd = dbconn.CreateCommand();

        //       dbcmd.CommandText = "UPDATE persons SET Photo = @img where PID = " + tid;
        dbcmd.CommandText = "UPDATE relatives set Photo = @img, relation = '" + fn1 + "', name = '" + ln1 + "' where (PID = " + pid + " and RID = " + rid + ")";
        dbcmd.Prepare();

        SqliteParameter param = new SqliteParameter("@img", DbType.Binary, data.Length);
        param.Value = data;
        dbcmd.Parameters.Add(param);

        dbcmd.ExecuteNonQuery();

        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    void LoadRelImage()
    {
        string conn = "";

        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string query = "SELECT Photo FROM relatives WHERE PID = " + pid + " and RID = " + rid + ";";

        dbcmd.CommandText = query;
        //reader = dbcmd.ExecuteReader();
        byte[] data = (byte[])dbcmd.ExecuteScalar();

        if (data != null)
        {
            //File.WriteAllBytes("woman2.jpg", data);
            Texture2D sampleTexture = new Texture2D(2, 2);
            bool isLoaded = sampleTexture.LoadImage(data);
            if (isLoaded)
            {
                relimg.GetComponent<RawImage>().texture = sampleTexture;
                relmimg.texture = sampleTexture;
            }
        }
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    void LoadEmptyImage()
    {
        byte[] data = null;

            Texture2D sampleTexture = new Texture2D(2, 2);
            bool isLoaded = sampleTexture.LoadImage(data);
            if (isLoaded)
            {
                relimg.GetComponent<RawImage>().texture = sampleTexture;
                relmimg.texture = sampleTexture;
            }
    }
    public int GetLID(string nlid)
    {
        string conn = "";
        int res = 0;
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT LID FROM relations where relation = '" + nlid + "'";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();

        res = reader.GetInt32(0);

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    public int GetPID()
    {
        string conn = "";
        int res = 0;
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT PID FROM working";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();
        
        res = reader.GetInt32(0);
        
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    public int GetRID()
    {
        string conn = "";
        int res = 0;
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT count(*) FROM relatives where PID = " + pid;
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();

        res = reader.GetInt32(0);

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    public void OpenDB(string p)
    {
        if (!File.Exists(path))
        {
            WWW loadDB = new WWW("jar:file://" + Application.dataPath + "!/assets/" + p);
            while (!loadDB.isDone) { }
            // then save to Application.persistentDataPath
            File.WriteAllBytes(path, loadDB.bytes);
        }
    }
    public void WorkRID()
    {
        string conn = "";

        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "update working set RID = " + rid;
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void VacuumDB()
    {
        string conn = "";
        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "PRAGMA auto_vacuum = FULL";
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
}
