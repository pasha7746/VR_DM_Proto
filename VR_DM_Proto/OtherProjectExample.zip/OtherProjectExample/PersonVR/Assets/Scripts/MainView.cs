﻿using UnityEngine;
using UnityEngine.UI;
using System.Data;
using System;
using Mono.Data.SqliteClient;
using System.Collections.Generic;
//using Mono.Data.Sqlite;
using System.IO;

public class MainView : MonoBehaviour
{
    public GameObject img;

    public RawImage rmimg;

    public IDbConnection dbconn;
    public IDbCommand dbcmd;
    public IDataReader reader;

    public Text txt;

    [HideInInspector]
    public int relativechosen;

    [HideInInspector]
    public int pid;
    [HideInInspector]
    public string conn;

    [HideInInspector]
    public string path = "";

    void Start ()
    {
        int tid = 0;
        string dp = "";
        if (Application.platform != RuntimePlatform.Android)
        {
            path = Application.dataPath + "/StreamingAssets/PeopleDB.db";
        }
        else
        {
            path = Application.persistentDataPath + "/PeopleDB.db";
        }
        OpenDB("PeopleDB.db");
        tid = GetPID();
        pid = tid;
        dp = PopulatePerson();
        txt.text = dp;
        LoadImage();
    }
    public string PopulatePerson()
    {
        string conn = "";
        string res = "";
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT FirstName,Lastname FROM persons where PID = " + pid;
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();

        res = pid.ToString() + ". " + reader.GetString(1) + ", " + reader.GetString(0);

        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    void LoadImage()
    {
        string conn = "";

        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string query = "SELECT Photo FROM persons WHERE PID=" + pid + ";";

        dbcmd.CommandText = query;
        //reader = dbcmd.ExecuteReader();
        byte[] data = (byte[])dbcmd.ExecuteScalar();

        if (data != null)
        {
            //File.WriteAllBytes("woman2.jpg", data);
            Texture2D sampleTexture = new Texture2D(2, 2);
            bool isLoaded = sampleTexture.LoadImage(data);
            if (isLoaded)
            {
                img.GetComponent<RawImage>().texture = sampleTexture;
                rmimg.texture = sampleTexture;
            }
        }
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public int GetPID()
    {
        string conn = "";
        int res = 0;
        conn = "URI=file:" + path;

        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        dbcmd = dbconn.CreateCommand();

        string sqlQuery = "SELECT PID FROM working";
        dbcmd.CommandText = sqlQuery;
        reader = dbcmd.ExecuteReader();

        reader.Read();
        
        res = reader.GetInt32(0);
        
        reader.Close();
        reader = null;
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;

        return res; // return matches
    }
    public void OpenDB(string p)
    {
        if (!File.Exists(path))
        {
            WWW loadDB = new WWW("jar:file://" + Application.dataPath + "!/assets/" + p);
            while (!loadDB.isDone) { }
            // then save to Application.persistentDataPath
            File.WriteAllBytes(path, loadDB.bytes);
        }
    }
    public void WorkRID(int rid)
    {
        string conn = "";

        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "update working set RID = " + rid;
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
    public void VacuumDB()
    {
        string conn = "";
        conn = "URI=file:" + path;


        dbconn = (IDbConnection)new SqliteConnection(conn);
        dbconn.Open();

        IDbCommand dbcmd = dbconn.CreateCommand();

        string sqlQuery = "PRAGMA auto_vacuum = FULL";
        dbcmd.CommandText = sqlQuery;
        dbcmd.ExecuteNonQuery();
        dbcmd.Dispose();
        dbcmd = null;
        dbconn.Close();
        dbconn = null;
    }
}
