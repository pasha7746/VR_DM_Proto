﻿using UnityEngine;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    public GameObject cpb;

    public GameObject LoadingText;
    public Text ProgressIndicator;
    public Image LoadingBar;
    float currentValue;

    [HideInInspector]
    public int tg = 1;
    [HideInInspector]
    public float speed = 15;

    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
/*        if (tg == 0)
        {
            cpb.SetActive(true);
        }
        else if (tg == 1)
        {
            cpb.SetActive(false);
        }
*/        if (currentValue < 100)
        {
            currentValue += speed * Time.deltaTime;
            ProgressIndicator.text = ((int)currentValue).ToString() + "%";
            LoadingText.SetActive(true);
        }
        else if (currentValue > 99)
        {
            currentValue = 0;
        }
        else
        {
            LoadingText.SetActive(false);
            ProgressIndicator.text = "Done";
        }
        //LoadingText.text = ltxt.text;
        LoadingBar.fillAmount = currentValue / 100;
    }
}
